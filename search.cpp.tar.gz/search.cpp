#include <iostream>
#include <string>
using namespace std;

/*
    CITY RECORD MANAGEMENT SYSTEM
    =============================
    Developed by Group 2 Members:
    1. Robel Shitahun
    2. Natnael Sendeku
    3. Yabsira Markos
    4. Rahel Wondimu
    5. Rahel Ademe
    
    Course: Cyber Security 2nd Year Section A
    Project: Linked List Implementation for City Records
*/

// Structure name: Combination of first names of two group members (Yabsira + Rahel)
struct YabsiraRahel {
    int id;                    // City ID
    string RobelNatnael;       // City name - different combination of members' names (Robel + Natnael)
    int kebele;                // Kebele number (በቁጥር)
    string kebeleseme;         // Kebele name (በፊደል)
    YabsiraRahel* next;        // Pointer to next record
};

// Global pointer to the first record in the linked list
YabsiraRahel* head = NULL;

// Function to add a new city record
void addRecord() {
    // Create a new city record
    YabsiraRahel* newNode = new YabsiraRahel;
    
    cout << "\n--- Add New City Record ---\n";
    cout << "Enter City ID: ";
    cin >> newNode->id;
    cout << "Enter City Name: ";
    cin.ignore(); // Clear input buffer
    getline(cin, newNode->RobelNatnael);
    cout << "Enter Kebele Number: ";
    cin >> newNode->kebele;
    cout << "Enter Kebele Name: ";
    cin.ignore(); // Clear input buffer
    getline(cin, newNode->kebeleseme);
    
    // Initialize the next pointer
    newNode->next = NULL;
    
    // Add to linked list
    if (head == NULL) {
        // If list is empty, make this the first record
        head = newNode;
    } else {
        // Find the last record and add new one at the end
        YabsiraRahel* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    
    cout << "City record added successfully!\n";
}

// Function to display all city records
void displayList() {
    if (head == NULL) {
        cout << "\nThe list is empty. No records to display.\n";
        return;
    }
    
    cout << "\n--- All City Records ---\n";
    YabsiraRahel* temp = head;
    int record_count = 1;
    
    while (temp != NULL) {
        cout << "\nRecord #" << record_count << endl;
        cout << "City ID: " << temp->id << endl;
        cout << "City Name: " << temp->RobelNatnael << endl;
        cout << "Kebele Number: " << temp->kebele << endl;
        cout << "Kebele Name: " << temp->kebeleseme << endl;
        cout << "------------------------";
        
        temp = temp->next;
        record_count++;
    }
    cout << "\nTotal records: " << record_count - 1 << endl;
}

// Function to search for a city by ID
void searchByID() {
    if (head == NULL) {
        cout << "\nThe list is empty. Cannot search.\n";
        return;
    }
    
    int search_id;
    cout << "\n--- Search City by ID ---\n";
    cout << "Enter City ID to search: ";
    cin >> search_id;
    
    YabsiraRahel* temp = head;
    bool found = false;
    
    while (temp != NULL) {
        if (temp->id == search_id) {
            cout << "\nRecord found!\n";
            cout << "City ID: " << temp->id << endl;
            cout << "City Name: " << temp->RobelNatnael << endl;
            cout << "Kebele Number: " << temp->kebele << endl;
            cout << "Kebele Name: " << temp->kebeleseme << endl;
            found = true;
            break;
        }
        temp = temp->next;
    }
    
    if (!found) {
        cout << "No city found with ID: " << search_id << endl;
    }
}

// Function to update city record details
void updateDetails() {
    if (head == NULL) {
        cout << "\nThe list is empty. Cannot update.\n";
        return;
    }
    
    int update_id;
    cout << "\n--- Update City Record ---\n";
    cout << "Enter City ID to update: ";
    cin >> update_id;
    
    YabsiraRahel* temp = head;
    bool found = false;
    
    while (temp != NULL) {
        if (temp->id == update_id) {
            cout << "\nCurrent record details:\n";
            cout << "City Name: " << temp->RobelNatnael << endl;
            cout << "Kebele Number: " << temp->kebele << endl;
            cout << "Kebele Name: " << temp->kebeleseme << endl;
            
            cout << "\nEnter new details:\n";
            cout << "Enter new City Name: ";
            cin.ignore();
            getline(cin, temp->RobelNatnael);
            cout << "Enter new Kebele Number: ";
            cin >> temp->kebele;
            cout << "Enter new Kebele Name: ";
            cin.ignore();
            getline(cin, temp->kebeleseme);
            
            cout << "Record updated successfully!\n";
            found = true;
            break;
        }
        temp = temp->next;
    }
    
    if (!found) {
        cout << "No city found with ID: " << update_id << endl;
    }
}

// Function to delete a city record
void deleteRecord() {
    if (head == NULL) {
        cout << "\nThe list is empty. Cannot delete.\n";
        return;
    }
    
    int delete_id;
    cout << "\n--- Delete City Record ---\n";
    cout << "Enter City ID to delete: ";
    cin >> delete_id;
    
    YabsiraRahel* temp = head;
    YabsiraRahel* prev = NULL;
    
    // Check if the first record needs to be deleted
    if (head->id == delete_id) {
        head = head->next;
        delete temp;
        cout << "Record deleted successfully!\n";
        return;
    }
    
    // Search for the record to delete
    while (temp != NULL && temp->id != delete_id) {
        prev = temp;
        temp = temp->next;
    }
    
    if (temp == NULL) {
        cout << "No city found with ID: " << delete_id << endl;
        return;
    }
    
    // Remove the record from the list
    prev->next = temp->next;
    delete temp;
    cout << "Record deleted successfully!\n";
}

// Function to display the main menu
void displayMenu() {
    cout << "\n======================================\n";
    cout << "    CITY RECORD MANAGEMENT SYSTEM\n";
    cout << "======================================\n";
    cout << "1. Add New Record\n";
    cout << "2. Display All Records\n";
    cout << "3. Search by ID\n";
    cout << "4. Update Details\n";
    cout << "5. Delete a Record\n";
    cout << "6. Exit Program\n";
    cout << "======================================\n";
    cout << "Please enter your choice (1-6): ";
}

// Main function
int main() {
    int choice;
    
    cout << "\nCITY RECORD MANAGEMENT SYSTEM\n";
    cout << "Developed by Group 2\n";
    cout << "Cyber Security 2nd Year Section A\n";
    
    while (true) {
        displayMenu();
        cin >> choice;
        
        if (choice == 1) {
            addRecord();
        }
        else if (choice == 2) {
            displayList();
        }
        else if (choice == 3) {
            searchByID();
        }
        else if (choice == 4) {
            updateDetails();
        }
        else if (choice == 5) {
            deleteRecord();
        }
        else if (choice == 6) {
            cout << "\nThank you for using the City Record System.\n";
            cout << "Program terminated.\n";
            break;
        }
        else {
            cout << "\nInvalid choice! Please enter a number between 1 and 6.\n";
        }
    }
    
    return 0;
}